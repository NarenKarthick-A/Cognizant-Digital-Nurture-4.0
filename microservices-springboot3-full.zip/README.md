# Microservices with Spring Boot 3 and Spring Cloud
This project includes:
- Account Service
- Loan Service
- API Gateway using Spring Cloud Gateway
- Eureka Discovery Server
